package ua.butdetal.nespy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
        }
        status = TextView(this).apply {
            text = "Режим вимкнено"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val on = Button(this).apply {
            text = "УВІМКНУТИ"
            setOnClickListener {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                startForegroundService(Intent(this@MainActivity, KeepAwakeService::class.java).setAction("ON"))
                status.text = "Екран не засинатиме"
            }
        }
        val off = Button(this).apply {
            text = "ВИМКНУТИ"
            setOnClickListener {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                stopService(Intent(this@MainActivity, KeepAwakeService::class.java))
                status.text = "Режим вимкнено"
            }
        }
        layout.addView(status)
        layout.addView(on)
        layout.addView(off)
        setContentView(layout)
    }
}
