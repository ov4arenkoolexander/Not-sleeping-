package ua.butdetal.nespy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class KeepAwakeService : Service() {
    private var lock: PowerManager.WakeLock? = null
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("awake", "Не спи", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "awake")
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }.setContentTitle("Не спи активний")
            .setContentText("Екран утримується активним")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .build()
        startForeground(1, notification)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        lock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "NeSpy:DisplayAwake")
        lock?.acquire()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        lock?.let { if (it.isHeld) it.release() }
        lock = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
